# Plum — Purple Cube Friend

Read plum-service/SETUP.md to install the AI edition on a Bedrock Dedicated Server.
This zip contains the server packs and a Python service; it is not a mobile import file.

## Play

1. Spawn two friends with Plum Spawn Egg in Creative, or /summon plum:friend ~ ~ ~.
2. Give each a plum fruit to tame them. They follow their owner.
3. Hold a book and interact (Talk to Plum on touch, right-click on PC).
4. Choose Ask a question and type your message. Replies are private.
5. Feed two nearby tamed adults a plum each to breed a half-size baby.
6. Tame the baby with a plum too. Babies grow in 20 loaded minutes; plums help.
7. Stay within 8 blocks of your tamed friend for regeneration.

Find plum trees in newly generated plains and forests. Break their fruit-speckled leaves
in Survival for plums and saplings. Plant a sapling on soil with a clear 5-wide, 6-high
space; wait for growth or use bone meal. Leaves do not decay automatically.
Plums replace apples for breeding and baby growth. You can eat them too.

Updating from 1.0.0: replace both pack folders and the bridge script, update each Plum
world-pack-list entry to [1,1,0], and restart. Keep existing credentials and UUIDs.

Plum resists ordinary damage and does not naturally despawn. Administrative removal,
/kill, and engine edge cases are outside this protection. Unloaded companions cannot
be moved by scripts; return to their area if needed. Cube friends have no Survival spawn recipe.

Automated tests pass. In-game behavior and live AI calls still need verification.
The AI service needs a privately configured OpenAI API key with API access/billing.
