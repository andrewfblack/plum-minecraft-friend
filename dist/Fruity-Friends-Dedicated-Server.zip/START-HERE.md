# Fruity Friends

Read plum-service/SETUP.md to install the AI edition on a Bedrock Dedicated Server.
This zip contains the server packs and a Python service; it is not a mobile import file.

## Play

1. To start in Survival, use a plum, apple or blueberry fruit on tilled farmland: a sprout appears
   and grows into a baby friend on its own (or interact with it to sprout it immediately).
   In Creative, spawn friends with the matching Spawn Egg instead.
2. Give each friend its own fruit to tame them: a plum tames Plum, an apple tames Apple, and a
   blueberry tames Blueberry.
   A newly tamed friend stays put where it is. Interact with an empty hand (or, for Blueberry,
   choose Movement in his chest menu) to open the Movement menu: Follow, Stay, Work, or Go Home.
   Up to four friends can follow you at once. Work keeps a friend within 20 blocks of where you
   set it; Go Home sends a friend to your spawn point, where it roams within 10 blocks.
3. Hold a book and interact (Talk to Plum / Talk to Apple / Talk to Blueberry on touch, right-click on PC).
4. Choose Ask a question and type your message. Replies are private.
5. Plant a fruit on tilled farmland to grow a baby friend; it sprouts and grows in 20 loaded minutes.
6. Tame the baby with its fruit. Fruit also speeds growth. Stay within 8 blocks of your tamed Plum for regeneration. Apple does not heal you;
   instead she owns Applezon and delivers a surprise or a search result for one apple fruit.
7. Blueberry is the Collector: dropped items within four blocks go straight into his chest. Interact with
   him with an empty hand to open it, store what you are holding, take something out, or choose Movement.
8. Craft a Fruit Basket from three sticks in the bucket shape, then hold it and interact with a tamed
   friend to tuck them inside (Blueberry keeps his chest contents). Carry them in your inventory and interact with a block to let them out again — they always come out in Stay mode, waiting for your next order.

Find plum, apple and blueberry trees in newly generated plains and forests. Break their fruit-speckled
leaves in Survival for the matching fruit and sapling. Plant a sapling on soil with a clear
5-wide, 6-high space; wait for growth or use bone meal. Leaves do not decay automatically.
The fruit works as a seed and snack: plant it on farmland to grow a baby friend.

Updating from 1.1.0: replace both pack folders and the bridge script, update each Fruity Friends
world-pack-list entry to [1,2,12], and restart. Keep existing credentials and UUIDs.

Friends resist ordinary damage and do not naturally despawn. Administrative removal,
/kill, and engine edge cases are outside this protection. Unloaded companions cannot
be moved by scripts; return to their area if needed. Cube friends have no Survival spawn recipe.

Automated tests pass. In-game behavior and live AI calls still need verification.
The AI service needs a privately configured OpenAI API key with API access/billing.
