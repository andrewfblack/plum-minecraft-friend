# Fruity Friends

Read plum-service/SETUP.md to install the AI edition on a Bedrock Dedicated Server.
This zip contains the server packs and a Python service; it is not a mobile import file.

## Play

1. To start in Survival, use a plum, apple, blueberry, lemon, banana, grape, strawberry or coconut fruit on tilled farmland: a sprout appears
   and grows into a baby friend on its own (or interact with it to sprout it immediately).
   In Creative, spawn friends with the matching Spawn Egg instead.
2. Give each friend its own fruit to tame them: a plum tames Plum, an apple tames Apple, a
   blueberry tames Blueberry, a lemon tames Lemon, a banana tames Banana, grapes tame Grapes,
   a strawberry tames Strawberry, and a coconut tames Coconut.
   A newly tamed friend stays put where it is. Interact with an empty hand (or, for Blueberry and Strawberry,
   choose Movement in their chest menu) to open the Movement menu: Follow, Stay, Work, or Go Home.
   Up to six friends can follow you at once. Work keeps a friend within 20 blocks of where you
   set it; Go Home sends a friend to your spawn point, where it roams within 10 blocks.
3. Hold a book and interact (Talk to Plum / Talk to Apple / Talk to Blueberry / Talk to Lemon / Talk to Banana / Talk to Grapes / Talk to Strawberry / Talk to Coconut on touch, right-click on PC).
4. Choose Ask a question and type your message. Replies are private.
5. Plant a fruit on tilled farmland to grow a baby friend; it sprouts and grows in 20 loaded minutes.
6. Tame the baby with its fruit; more fruit speeds its growth. Stay within 8 blocks of your tamed Plum for regeneration. Apple does not heal you;
   instead she owns Applezon and delivers a surprise or a search result for one apple fruit.
7. Blueberry is the Collector: dropped items within four blocks go straight into his chest. Interact with
   him with an empty hand to open it, store what you are holding, take something out, or choose Movement.
8. Lemon is the Light Friend: he drops a real light block at his feet as he moves, so he
   lights the way with moving block light instead of Night Vision.
   Lemon does not heal you; stay near your tamed Plum for that.
9. Banana is the Prankster: he is convinced he is your bodyguard. About every 30 seconds he drops a
   non-pickup banana peel trap. The first hostile mob that steps close slips and slows; an unused peel
   removes itself after two minutes. He does not heal you and
   his co-workers are unimpressed.
10. Grapes is the Sharpshooter: this squarish bunch of green grapes spits grape seeds at hostile mobs
    (no bow and arrow - just seeds). A tamed Grapes takes aim at monsters within 12 blocks, dealing
    damage with lovely arcing spits. Grapes does not heal you; stay near your tamed Plum for that.
11. Strawberry is the Farmer: the only cube friend whose job changes with his mode. Set him to Work and he
    tends fields - he quickens immature wheat, carrots, potatoes, and beetroot, harvests ripe crops, and
    replants the seeds so the field keeps producing. Following (or staying at home), he forages instead:
    he still speeds growth and gathers ripe crops, breaks grass looking for seeds, and never replants.
    Everything he gathers goes into his own farm chest: interact with him with an empty hand to open it,
    store what you hold, take the harvest out, or pick Movement. Strawberry does not heal you; stay near
    your tamed Plum for that.
12. Coconut is the Bodyguard: about every three seconds he checks for hostile mobs around him and slams
    the palm-frond ground, knocking every monster nearby away with a bit of damage. Set him to Work and
    he guards that spot with a wider radius (8 blocks); following or staying at home, he escorts you and
    guards up to 6 blocks around wherever he is. He only slams when something hostile is actually close,
    and he does not heal you; stay near your tamed Plum for that.
13. Craft a Fruit Basket from three sticks in the bucket shape, then hold it and interact with a tamed
    friend to tuck them inside (Blueberry keeps his chest contents; Strawberry keeps his farm chest).
    Carry them in your inventory and interact with a block to let them out again — they always come out in Stay mode, waiting for your next order.

Find plum, apple, blueberry and grape trees in newly generated plains and forests, lemon trees in warm
biomes like deserts, savannas and jungles, banana trees in jungles, low strawberry bushes in plains
only, and tall coconut palms on beaches. Break their fruit-speckled leaves in Survival for the matching
fruit and sapling. Plant a sapling
on soil with a clear space (strawberries need just a tiny 3-wide, 2-high pocket; the other fruit trees
need 5-wide, 6-high; coconut palms are taller and need 5-wide, 7-high); wait for growth or use bone meal.
Leaves do not decay automatically.
The fruit works as a seed and snack: plant it on farmland to grow a baby friend.

Updating from 1.1.0: replace both pack folders and the bridge script, update each Fruity Friends
world-pack-list entry to [1,2,31], and restart. Keep existing credentials and UUIDs.

Friends resist ordinary damage and do not naturally despawn. Administrative removal,
/kill, and engine edge cases are outside this protection. Unloaded companions cannot
be moved by scripts; return to their area if needed. Cube friends have no Survival spawn recipe.

Automated tests pass. In-game behavior and live AI calls still need verification.
The AI service needs a privately configured OpenAI API key with API access/billing.
